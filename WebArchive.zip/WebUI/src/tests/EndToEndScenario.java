package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class EndToEndScenario extends BasePage {
	
	String username = objProperty.getData("Username");
	String password = objProperty.getData("Password");
	


	@Test(groups = {"Login"})
	   public void login() {
	    
	    driver.get("https://example.com/login");
       
       WebElement username = driver.findElement(ExpectedConditions.presenceOfElementLocated(By.id("user-name")));
       username.sendKeys("username");

       WebElement password = driver.findElement(ExpectedConditions.presenceOfElementLocated(By.id("password")));
       password.sendKeys("password");
    
       WebElement login = driver.findElement(ExpectedConditions.elementToBeClickable(By.id("login-button")));
       login.click();
       
       WebElement logout = driver.findElement(ExpectedConditions.elementToBeClickable(By.id("logout-button")));
       logout.click();

	    }
	
	@Test(groups = {"Checkout"})
	public void checkout() {
		
	       WebElement username = driver.findElement(ExpectedConditions.presenceOfElementLocated(By.id("user-name")));
	       username.sendKeys("username");

	       WebElement password = driver.findElement(ExpectedConditions.presenceOfElementLocated(By.id("password")));
	       password.sendKeys("password");
	    
	       WebElement login = driver.findElement(ExpectedConditions.elementToBeClickable(By.id("login-button")));
	       login.click();
	       
	       WebElement backpakAddbutton = driver.findElement(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='add-to-cart-sauce-labs-backpack']")));
	       backpakAddbutton.click();
	       
	       WebElement redTshertAddButton = driver.findElement(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='add-to-cart-test.allthethings()-t-shirt-(red)']")));
	       redTshertAddButton.click();
	       
	       WebElement shoppingCartIcon = driver.findElement(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='shopping_cart_link']")));
	       shoppingCartIcon.click();
	       
	       WebElement checkoutButton = driver.findElement(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='checkout']")));
	       checkoutButton.click();
	       
	       WebElement logout = driver.findElement(ExpectedConditions.elementToBeClickable(By.id("logout-button")));
	       logout.click();
	}
	    
	    

}
