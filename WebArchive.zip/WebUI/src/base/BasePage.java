package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class BasePage {
	
	 private WebDriver driver;
	 PropertyReader objProperty = new Propertyreader("config.properties");
	 
	 public WebDriver getDriver(WebDriver driver, String browserType) {
		 switch (browserType) { 
		 case "FF":
			 System.setProperty("webdriver.gecko.driver", "C:\\drivers\geckodriver.exe")
			 driver = new FirefoxDriver();
			 break;
		 case "chrome":
			 System.setProperty("webdriver.chrome.driver", "C:\\drivers\chromedriver.exe")
			 driver = new ChromeDriver();
		 }
		 
		 driver.manage().window().maximize();
		 driver.manage().deleteCookies();
	 }

	    @BeforeClass
	    public void setUp() {
	        
	    	driver.getDriver(driver, objProperty.getData("Browser"));
	       
	    }
	    
	    @AfterClass
	    public void tearDown() {
	        if (driver != null) {
	            driver.quit();
	        }
	    }

}
