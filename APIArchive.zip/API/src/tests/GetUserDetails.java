package tests;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetUserDetails {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://reqres.in"; // Example base URI
    }

    @Test
    public void testGetUserDetails() {
        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .when()
                .get("/api/users/2")
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Validate status code
        Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200");

        // Extract "data" object from response
        Map<String, Object> user = response.jsonPath().getMap("data");
        Assert.assertNotNull(user, "User data should not be null");

        // Assert expected user fields
        Assert.assertEquals(user.get("id"), 2, "User ID should be 2");
        Assert.assertTrue(user.containsKey("email"), "User should have email");
        Assert.assertTrue(user.containsKey("first_name"), "User should have first_name");
        Assert.assertTrue(user.containsKey("last_name"), "User should have last_name");

        // Check email format
        String email = (String) user.get("email");
        Assert.assertTrue(email.contains("@"), "Email should contain '@'");

        // Optional: print details
        System.out.println("User Details: " + user);
    }
}