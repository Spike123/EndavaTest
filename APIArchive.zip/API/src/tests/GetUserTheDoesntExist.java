package tests;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetUserTheDoesntExist {
	
	   @BeforeClass
	    public void setup() {
	        RestAssured.baseURI = "https://reqres.in"; // Example base URI
	    }

	    @Test
	    public void testGetUserDetails() {
	        Response response = RestAssured
	                .given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("/api/users/34ewr")
	                .then()
	                .statusCode(404)
	                .extract()
	                .response();

	        // Validate status code
	        Assert.assertEquals(response.getStatusCode(), 404, "Status code should be 200");
	        Assert.assertTrue(response.getStatusLine().contains("Not found"), "Status message should be 'Not found'");
	        
	    }

}
