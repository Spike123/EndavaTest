package tests;

import java.util.Map;

import org.junit.AfterClass;
import org.testng.Assert;
import org.testng.Test;
import org.testng.annotations.BeforeClass;

import DTOs.CreateUserDTO;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CreateUser {
	

	 @BeforeClass
	    public void setup() {
	        RestAssured.baseURI = "https://reqres.in"; // Example base URI
	    }

	
	@Test
    public void testCreateUser() {
        // Create request DTO
        CreateUserDTO request = new CreateUserDTO("niki01", "niki@mail.com", "PaSS123!");

        // Send POST request using request DTO and map response to response DTO
        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(request) // request DTO
                .when()
                .post("/api/users")
                .then()
                .statusCode(201)
                .extract()
                .response();
                

        Map<String, Object> user = response.jsonPath().getMap("data");
        Assert.assertEquals(response.getStatusCode(), 201, "Status code should be 200");
        
        Assert.assertEquals(user.get("username"), request.getUsername(),  "Username is not correct");
        Assert.assertEquals(user.get("email"), request.getEmail(),  "Email is not correct");
	}
        
        @AfterClass
        public void closeDriver() {
            driver.quit();
        }
}
  